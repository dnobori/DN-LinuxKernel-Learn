#ifndef S390_BLACKLIST_H
#define S390_BLACKLIST_H

extern int is_blacklisted (int ssid, int devno);

#endif
