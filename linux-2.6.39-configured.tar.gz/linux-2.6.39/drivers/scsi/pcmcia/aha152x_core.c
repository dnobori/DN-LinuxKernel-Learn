#define PCMCIA	1
#define AHA152X_STAT 1
#include "aha152x.c"
