#ifndef _ELF_H
# include <elf/elf.h>
/* Some information which is not meant for the public and therefore not
   in <elf.h>.  */
# include <dl-dtprocnum.h>
#endif
