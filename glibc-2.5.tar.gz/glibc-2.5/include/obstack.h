#include <malloc/obstack.h>

libc_hidden_proto (_obstack_newchunk)
