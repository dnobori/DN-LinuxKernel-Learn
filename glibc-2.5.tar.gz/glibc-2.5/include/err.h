#include <misc/err.h>

libc_hidden_proto (warn)
libc_hidden_proto (warnx)
libc_hidden_proto (vwarn)
libc_hidden_proto (vwarnx)
libc_hidden_proto (verr)
libc_hidden_proto (verrx)
