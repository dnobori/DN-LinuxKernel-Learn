#ifndef _UTIME_H

#include <io/utime.h>

libc_hidden_proto (utime)

#endif /* utime.h */
