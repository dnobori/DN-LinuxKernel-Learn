#include <sunrpc/rpc/pmap_rmt.h>

extern bool_t xdr_rmtcall_args_internal (XDR *__xdrs,
					 struct rmtcallargs *__crp)
  attribute_hidden;
extern bool_t xdr_rmtcallres_internal (XDR *__xdrs, struct rmtcallres *__crp)
  attribute_hidden;
